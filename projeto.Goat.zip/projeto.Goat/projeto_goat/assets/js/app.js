
let quantidadePessoas = 5;
const minimoPessoas = 1;
const maximoPessoas = 20;


const elementoNumero = document.getElementById('numeroPessoas');
const elementoDica = document.getElementById('dicaPessoas');
const barraProgresso = document.querySelector('.barra-progresso');
const botaoVoltar = document.querySelector('.botao-voltar');
const opcoesRapidas = document.querySelectorAll('.opcao');
const botaoMenos = document.getElementById('botaoMenos');
const botaoMais = document.getElementById('botaoMais');


function iniciarEtapa1() {
  opcoesRapidas.forEach(botao => {
    const valor = parseInt(botao.dataset.numero, 10);
    botao.classList.toggle('ativo', valor === quantidadePessoas);
    botao.addEventListener('click', () => definirQuantidade(valor));
  });

  botaoMenos.addEventListener('click', () => alterarQuantidade(-1));
  botaoMais.addEventListener('click', () => alterarQuantidade(1));

  botaoVoltar.addEventListener('click', () => {

  });

  atualizarInterface();
}

function definirQuantidade(valor) {
  quantidadePessoas = limitar(valor, minimoPessoas, maximoPessoas);
  atualizarInterface();
}

function alterarQuantidade(delta) {
  definirQuantidade(quantidadePessoas + delta);
}

function atualizarInterface() {
  elementoNumero.textContent = quantidadePessoas;
  elementoDica.textContent = quantidadePessoas === 1
    ? '1 pessoa selecionada'
    : `${quantidadePessoas} pessoas selecionadas`;

  opcoesRapidas.forEach(botao => {
    const valor = parseInt(botao.dataset.numero, 10);
    botao.classList.toggle('ativo', valor === quantidadePessoas);
  });

  barraProgresso.style.width = '12.5%';
  botaoVoltar.disabled = true;
}

function limitar(valor, minimo, maximo) {
  return Math.max(minimo, Math.min(maximo, valor));
}

function irParaEtapa(numero) {
  const etapas = document.querySelectorAll('.etapa');
  etapas.forEach((etapa, indice) => {
    etapa.style.display = (indice === numero - 1) ? 'block' : 'none';
  });
}


const diasCalendario = document.getElementById('diasCalendario');
const rotuloMes = document.getElementById('rotuloMes');
const dicaData = document.getElementById('dicaData');

let mesAtual = 8;
let anoAtual = 2025;
let diaSelecionado = null;

const nomesMeses = [
  "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
  "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
];

function renderizarCalendario() {
  diasCalendario.innerHTML = "";
  const primeiroDia = new Date(anoAtual, mesAtual, 1).getDay();
  const diasNoMes = new Date(anoAtual, mesAtual + 1, 0).getDate();
  const deslocamento = (primeiroDia === 0 ? 6 : primeiroDia - 1);

  for (let i = 0; i < deslocamento; i++) {
    const vazio = document.createElement('div');
    vazio.classList.add('dia', 'vazio');
    diasCalendario.appendChild(vazio);
  }

  for (let d = 1; d <= diasNoMes; d++) {
    const botaoDia = document.createElement('button');
    botaoDia.classList.add('dia');
    botaoDia.textContent = d;
    botaoDia.onclick = () => selecionarDia(d);
    if (diaSelecionado === d && mesAtual === 8 && anoAtual === 2025) {
      botaoDia.classList.add('ativo');
    }
    diasCalendario.appendChild(botaoDia);
  }

  rotuloMes.textContent = `${nomesMeses[mesAtual]} ${anoAtual}`;
}

function selecionarDia(dia) {
  diaSelecionado = dia;
  dicaData.textContent = `Data selecionada: ${dia} de ${nomesMeses[mesAtual]} de ${anoAtual}`;
  renderizarCalendario();
}

document.getElementById('mesAnterior').onclick = () => {
  if (mesAtual === 0) {
    mesAtual = 11;
    anoAtual--;
  } else {
    mesAtual--;
  }
  renderizarCalendario();
};

document.getElementById('mesSeguinte').onclick = () => {
  if (mesAtual === 11) {
    mesAtual = 0;
    anoAtual++;
  } else {
    mesAtual++;
  }
  renderizarCalendario();
};


const botoesServico = document.querySelectorAll('.botao-servico');
const dicaServico = document.getElementById('dicaServico');
let servicoSelecionado = null;

botoesServico.forEach(botao => {
  botao.addEventListener('click', () => {
    servicoSelecionado = botao.dataset.servico;
    dicaServico.textContent = `Serviço selecionado: ${servicoSelecionado}`;
    botoesServico.forEach(b => b.classList.remove('ativo'));
    botao.classList.add('ativo');
  });
});


const botoesHorario = document.querySelectorAll('.botao-horario');
const dicaHorario = document.getElementById('dicaHorario');
let horarioSelecionado = null;

botoesHorario.forEach(botao => {
  botao.addEventListener('click', () => {
    horarioSelecionado = botao.textContent;
    dicaHorario.textContent = `Horário selecionado: ${horarioSelecionado}`;
    botoesHorario.forEach(b => b.classList.remove('ativo'));
    botao.classList.add('ativo');
  });
});


const botoesRestricao = document.querySelectorAll('.botao-restricao');
const dicaRestricao = document.getElementById('dicaRestricao');
let restricaoSelecionada = null;

botoesRestricao.forEach(botao => {
  botao.addEventListener('click', () => {
    restricaoSelecionada = botao.dataset.valor;
    dicaRestricao.textContent = `Restrições: ${restricaoSelecionada.toUpperCase()}`;
    botoesRestricao.forEach(b => b.classList.remove('ativo'));
    botao.classList.add('ativo');
  });
});


const botoesOcasião = document.querySelectorAll('.botao-ocasiao');
const dicaOcasião = document.getElementById('dicaOcasião');
let ocasiãoSelecionada = null;

botoesOcasião.forEach(botao => {
  botao.addEventListener('click', () => {
    ocasiãoSelecionada = botao.dataset.valor;
    dicaOcasião.textContent = `Ocasião selecionada: ${ocasiãoSelecionada}`;
    botoesOcasião.forEach(b => b.classList.remove('ativo'));
    botao.classList.add('ativo');
  });
});


document.addEventListener('DOMContentLoaded', () => {
  renderizarCalendario();
  iniciarEtapa1();
});
function irParaEtapa(numero) {
  // validações simples
  if (numero === 2 && quantidadePessoas < 1) {
    alert("Selecione a quantidade de pessoas!");
    return;
  }
  if (numero === 3 && !diaSelecionado) {
    alert("Selecione uma data!");
    return;
  }
  if (numero === 4 && !servicoSelecionado) {
    alert("Selecione um serviço!");
    return;
  }

  // mostra a etapa certa
  const etapas = document.querySelectorAll('.etapa');
  etapas.forEach((etapa, idx) => {
    etapa.style.display = idx === numero - 1 ? 'block' : 'none';
  });
}

