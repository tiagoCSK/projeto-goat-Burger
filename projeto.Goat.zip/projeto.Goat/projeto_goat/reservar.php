<?php

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <title>GOAT Burguer - Reserva</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="stylesheet" href="assets/css/reservar.css" />
</head>
<body>
  <div class="fundo-escuro"></div>


  <div class="barra-topo">
    <div class="idioma">
      <select aria-label="Idioma" id="seletorIdioma">
        <option value="pt" selected>PT</option>
        <option value="en">EN</option>
        <option value="es">ES</option>
      </select>
    </div>
    <div class="marca-topo">GOAT BURGUER</div>
    <button class="perfil" aria-label="Perfil">👤</button>
  </div>


  <main class="conteudo">


    <section class="cartao etapa" id="etapa1">
      <header class="cabecalho-cartao">
        <div class="logo"><img src="assets/img/logo-goatburger.png" alt="Logo" /></div>
        <hr class="divisor" />
      </header>
      <h2 class="titulo">Selecione a quantidade de <b>pessoas</b></h2>

      <div class="opcoes" id="opcoesRapidas">
        <button class="opcao" data-numero="1">1</button>
        <button class="opcao" data-numero="2">2</button>
        <button class="opcao" data-numero="3">3</button>
        <button class="opcao" data-numero="4">4</button>
        <button class="opcao" data-numero="5">5</button>
      </div>

      <div class="contador">
        <button class="controle" id="botaoMenos">−</button>
        <div class="numero" id="numeroPessoas">5</div>
        <button class="controle" id="botaoMais">+</button>
      </div>

      <div class="dica" id="dicaPessoas">5 pessoas selecionadas</div>

      <div class="progresso"><div class="barra-progresso" style="width: 12.5%"></div></div>
      <button class="botao-voltar" disabled>← Voltar</button>
      <button class="botao-avancar" onclick="irParaEtapa(2)">Próximo</button>
    </section>


    <section class="cartao etapa" id="etapa2" style="display:none;">
      <header class="cabecalho-cartao">
        <div class="logo"><img src="assets/img/logo-goatburger.png" alt="Logo" /></div>
        <hr class="divisor" />
      </header>
      <h2 class="titulo">Selecione a <b>data</b> da reserva</h2>

      <div class="calendario">
        <div class="cabecalho-calendario">
          <button id="mesAnterior">←</button>
          <div id="rotuloMes">Setembro 2025</div>
          <button id="mesSeguinte">→</button>
        </div>
        <div class="dias-semana">
          <span>SEG</span><span>TER</span><span>QUA</span><span>QUI</span><span>SEX</span><span>SÁB</span><span>DOM</span>
        </div>
        <div class="dias-calendario" id="diasCalendario"></div>
      </div>

      <div class="dica" id="dicaData">Nenhuma data selecionada</div>

      <div class="progresso"><div class="barra-progresso" style="width: 25%"></div></div>
      <button class="botao-voltar" onclick="irParaEtapa(1)">← Voltar</button>
      <button class="botao-avancar" onclick="irParaEtapa(3)">Próximo</button>
    </section>

    <section class="cartao etapa" id="etapa3" style="display:none;">
      <header class="cabecalho-cartao">
        <div class="logo"><img src="assets/img/logo-goatburger.png" alt="Logo" /></div>
        <hr class="divisor" />
      </header>

      <h2 class="titulo">Preferência de <b>serviço</b></h2>

      <div class="opcoes-servico">
        <button class="botao-servico" data-servico="Almoço">Almoço</button>
        <button class="botao-servico" data-servico="Jantar">Jantar</button>
      </div>

      <div class="dica" id="dicaServico">Nenhuma preferência selecionada</div>

      <div class="progresso"><div class="barra-progresso" style="width: 37.5%"></div></div>
      <button class="botao-voltar" onclick="irParaEtapa(2)">← Voltar</button>
      <button class="botao-avancar" onclick="irParaEtapa(4)">Próximo</button>
    </section>

    
    <section class="cartao etapa" id="etapa4" style="display:none;">
      <header class="cabecalho-cartao">
        <div class="logo"><img src="assets/img/logo-goatburger.png" alt="Logo" /></div>
        <hr class="divisor" />
      </header>

      <h2 class="titulo">Selecione o <b>horário</b> disponível</h2>

      <div class="colunas-horario">
        <div>
          <div class="rotulo-horario">Dia anterior<br><small>Qua 17, Set</small></div>
          <button class="botao-horario">12:00</button>
          <button class="botao-horario">12:30</button>
          <button class="botao-horario">13:00</button>
          <button class="botao-horario">13:30</button>
          <button class="botao-horario">14:00</button>
        </div>

        <div>
          <div class="rotulo-horario destaque">Reservas disponíveis<br><small>Qui 18, Set</small></div>
          <button class="botao-horario">12:00</button>
          <button class="botao-horario">12:30</button>
          <button class="botao-horario">13:00</button>
          <button class="botao-horario">13:30</button>
          <button class="botao-horario">14:00</button>
        </div>

        <div>
          <div class="rotulo-horario">Próximo dia<br><small>Sex 19, Set</small></div>
          <button class="botao-horario">12:00</button>
          <button class="botao-horario">12:30</button>
          <button class="botao-horario">13:00</button>
          <button class="botao-horario">13:30</button>
          <button class="botao-horario">14:00</button>
        </div>
      </div>

      <div class="dica" id="dicaHorario">Nenhum horário selecionado</div>

      <div class="progresso"><div class="barra-progresso" style="width: 50%"></div></div>
      <button class="botao-voltar" onclick="irParaEtapa(3)">← Voltar</button>
      <button class="botao-avancar" onclick="irParaEtapa(5)">Próximo</button>
    </section>

    <section class="cartao etapa" id="etapa5" style="display:none;">
      <header class="cabecalho-cartao">
        <div class="logo"><img src="assets/img/logo-goatburger.png" alt="Logo" /></div>
        <hr class="divisor" />
      </header>

      <h2 class="titulo">Restrições <b>alimentares</b></h2>

      <div class="resumo">
        <div><strong>3 pessoas</strong></div>
        <div><strong>SEX 19, SET</strong></div>
        <div><strong>12:00</strong></div>
      </div>

      <div class="pergunta">Possui restrições alimentares?</div>

      <div class="opcoes-restricao">
        <button class="botao-restricao" data-valor="não">NÃO</button>
        <button class="botao-restricao" data-valor="sim">SIM</button>
      </div>

      <div class="dica" id="dicaRestricao">Nenhuma preferência selecionada</div>

      <div class="progresso"><div class="barra-progresso" style="width: 62.5%"></div></div>
      <button class="botao-voltar" onclick="irParaEtapa(4)">← Voltar</button>
      <button class="botao-avancar" onclick="irParaEtapa(6)">Próximo</button>
    </section>


         <section class="cartao etapa" id="etapa6" style="display:none;">
      <header class="cabecalho-cartao">
        <div class="logo"><img src="assets/img/logo-goatburger.png" alt="Logo" /></div>
        <hr class="divisor" />
      </header>

      <h2 class="titulo">Notas para esta <b>reserva</b></h2>

      <div class="resumo">
        <div><strong>3 pessoas</strong></div>
        <div><strong>SEX 19, SET</strong></div>
        <div><strong>12:00</strong></div>
      </div>

      <textarea id="campoNotas" placeholder="Escreva aqui alguma observação..."></textarea>
      <p class="nota">Faremos o possível para atender suas solicitações, mas não podemos garantir.</p>

      <div class="pergunta">Ocasião especial? Escolha o motivo:</div>

      <div class="opcoes-ocasiao">
        <button class="botao-ocasiao" data-valor="Aniversário">🎉 Aniversário</button>
        <button class="botao-ocasiao" data-valor="Casamento">💍 Aniversário de casamento</button>
        <button class="botao-ocasiao" data-valor="Romântico">❤️ Encontro romântico</button>
        <button class="botao-ocasiao" data-valor="Negócios">💼 Reunião de negócios</button>
        <button class="botao-ocasiao" data-valor="Outro">✨ Outra ocasião especial</button>
      </div>

      <div class="dica" id="dicaOcasião">Nenhuma ocasião selecionada</div>

      <div class="progresso"><div class="barra-progresso" style="width: 75%"></div></div>
      <button class="botao-voltar" onclick="irParaEtapa(5)">← Voltar</button>
      <button class="botao-avancar" onclick="irParaEtapa(7)">Terminar</button>
    </section>


         <section class="cartao etapa" id="etapa7" style="display:none;">
      <header class="cabecalho-cartao">
        <div class="logo"><img src="assets/img/logo.png" alt="Logo" /></div>
        <hr class="divisor" />
      </header>

      <h2 class="titulo">Reserva <b>confirmada!</b></h2>

      <div class="resumo">
        <p><strong>Tiago Silva</strong></p>
        <p><strong>3 pessoas</strong></p>
        <p><strong>SEX 19, SET</strong></p>
        <p><strong>12:00</strong></p>
        <p><strong>Menu: À La Carte</strong></p>
        <p><strong>Restrições: NÃO</strong></p>
        <p><strong>Ocasião: Aniversário</strong></p>
      </div>

      <p class="nota">Qualquer dúvida, entre em contato: <b>reservas@grupoevo.com.br</b></p>

      <div class="progresso"><div class="barra-progresso" style="width: 100%"></div></div>
      <button class="botao-avancar" onclick="irParaEtapa(1)">Minhas reservas</button>
    </section>
  </main>

  <script src="assets/js/app.js"></script>
  <script src="assets/js/calendario.js"></script>
</body>
</html>
