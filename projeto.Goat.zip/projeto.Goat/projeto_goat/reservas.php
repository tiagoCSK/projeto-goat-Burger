<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Painel de Reservas</title>
  <link rel="stylesheet" href="assets/css/reservas.css">
</head>
<body>

  <div class="barra-topo">
    <div class="idioma">
      <select aria-label="Idioma" id="seletorIdioma">
        <option value="pt" selected>PT</option>
        <option value="en">EN</option>
        <option value="es">ES</option>
      </select>
    </div>
    <div class="marca-topo">GOAT BURGUER</div>
    <button class="perfil" aria-label="Perfil">👤</button>
  </div>

  <header>
    <h1>Painel de Reservas</h1>
  </header>

 
  <div class="resumo">
    <div class="card">
      <h2>12</h2>
      <p>Reservas de hoje</p>
    </div>
    <div class="card">
      <h2>36</h2>
      <p>Pessoas esperadas</p>
    </div>
    <div class="card">
      <h2>19h</h2>
      <p>Horário mais cheio</p>
    </div>
  </div>

   <div class="filtros">
    <input type="date">
    <select>
      <option>Status</option>
      <option>Confirmada</option>
      <option>Aguardando</option>
      <option>Cancelada</option>
      <option>Concluída</option>
    </select>
    <input type="text" placeholder="Buscar cliente...">
    <button>Filtrar</button>
  </div>

    <table>
    <thead>
      <tr>
        <th>Cliente</th>
        <th>Pessoas</th>
        <th>Horário</th>
        <th>Status</th>
        <th>Mesa</th>
        <th>Ações</th>
      </tr>
    </thead>
    <tbody>
  <tr>
    <td>Maria Silva</td>
    <td>4</td>
    <td>19:30</td>
    <td>Aguardando</td>
    <td>5</td>
    <td class="acoes">
      <button class="confirmar">Confirmar</button>
      <button class="editar">Editar</button>
      <button class="cancelar">Cancelar</button>
    </td>
  </tr>
  <tr>
    <td>João Pereira</td>
    <td>2</td>
    <td>20:00</td>
    <td>Confirmada</td>
    <td>2</td>
    <td class="acoes">
      <button class="concluida">Concluir</button>
      <button class="editar">Editar</button>
      <button class="cancelar">Cancelar</button>
    </td>
  </tr>
  <tr>
    <td>Ana Costa</td>
    <td>3</td>
    <td>18:45</td>
    <td>Aguardando</td>
    <td>7</td>
    <td class="acoes">
      <button class="confirmar">Confirmar</button>
      <button class="editar">Editar</button>
      <button class="cancelar">Cancelar</button>
    </td>
  </tr>
  <tr>
    <td>Lucas Almeida</td>
    <td>5</td>
    <td>21:00</td>
    <td>Confirmada</td>
    <td>10</td>
    <td class="acoes">
      <button class="concluida">Concluir</button>
      <button class="editar">Editar</button>
      <button class="cancelar">Cancelar</button>
    </td>
  </tr>
  <tr>
    <td>Fernanda Rocha</td>
    <td>2</td>
    <td>19:15</td>
    <td>Aguardando</td>
    <td>3</td>
    <td class="acoes">
      <button class="confirmar">Confirmar</button>
      <button class="editar">Editar</button>
      <button class="cancelar">Cancelar</button>
    </td>
  </tr>
  <tr>
    <td>Pedro Martins</td>
    <td>6</td>
    <td>20:30</td>
    <td>Confirmada</td>
    <td>12</td>
    <td class="acoes">
      <button class="concluida">Concluir</button>
      <button class="editar">Editar</button>
      <button class="cancelar">Cancelar</button>
    </td>
  </tr>
  <tr>
    <td>Juliana Oliveira</td>
    <td>4</td>
    <td>18:30</td>
    <td>Aguardando</td>
    <td>4</td>
    <td class="acoes">
      <button class="confirmar">Confirmar</button>
      <button class="editar">Editar</button>
      <button class="cancelar">Cancelar</button>
    </td>
  </tr>
  <tr>
    <td>Ricardo Mendes</td>
    <td>3</td>
    <td>20:45</td>
    <td>Confirmada</td>
    <td>8</td>
    <td class="acoes">
      <button class="concluida">Concluir</button>
      <button class="editar">Editar</button>
      <button class="cancelar">Cancelar</button>
    </td>
  </tr>
  <tr>
    <td>Camila Ferreira</td>
    <td>2</td>
    <td>19:50</td>
    <td>Aguardando</td>
    <td>1</td>
    <td class="acoes">
      <button class="confirmar">Confirmar</button>
      <button class="editar">Editar</button>
      <button class="cancelar">Cancelar</button>
    </td>
  </tr>
  <tr>
    <td>André Santos</td>
    <td>5</td>
    <td>21:15</td>
    <td>Confirmada</td>
    <td>9</td>
    <td class="acoes">
      <button class="concluida">Concluir</button>
      <button class="editar">Editar</button>
      <button class="cancelar">Cancelar</button>
    </td>
  </tr>
  <tr>
    <td>Beatriz Lima</td>
    <td>3</td>
    <td>18:15</td>
    <td>Aguardando</td>
    <td>6</td>
    <td class="acoes">
      <button class="confirmar">Confirmar</button>
      <button class="editar">Editar</button>
      <button class="cancelar">Cancelar</button>
    </td>
  </tr>
  <tr>
    <td>Carlos Nogueira</td>
    <td>2</td>
    <td>20:10</td>
    <td>Confirmada</td>
    <td>11</td>
    <td class="acoes">
      <button class="concluida">Concluir</button>
      <button class="editar">Editar</button>
      <button class="cancelar">Cancelar</button>
    </td>
  </tr>

   <tr>
    <td>Mariana Lopes</td>
    <td>3</td>
    <td>18:00</td>
    <td>Aguardando</td>
    <td>13</td>
    <td class="acoes">
      <button class="confirmar">Confirmar</button>
      <button class="editar">Editar</button>
      <button class="cancelar">Cancelar</button>
    </td>
  </tr>
  <tr>
    <td>Gustavo Ribeiro</td>
    <td>4</td>
    <td>19:10</td>
    <td>Confirmada</td>
    <td>14</td>
    <td class="acoes">
      <button class="concluida">Concluir</button>
      <button class="editar">Editar</button>
      <button class="cancelar">Cancelar</button>
    </td>
  </tr>
  <tr>
    <td>Patrícia Martins</td>
    <td>2</td>
    <td>20:20</td>
    <td>Aguardando</td>
    <td>15</td>
    <td class="acoes">
      <button class="confirmar">Confirmar</button>
      <button class="editar">Editar</button>
      <button class="cancelar">Cancelar</button>
    </td>
  </tr>
  <tr>
    <td>Renato Costa</td>
    <td>5</td>
    <td>21:30</td>
    <td>Confirmada</td>
    <td>16</td>
    <td class="acoes">
      <button class="concluida">Concluir</button>
      <button class="editar">Editar</button>
      <button class="cancelar">Cancelar</button>
    </td>
  </tr>
  <tr>
    <td>Sandra Teixeira</td>
    <td>3</td>
    <td>18:25</td>
    <td>Aguardando</td>
    <td>17</td>
    <td class="acoes">
      <button class="confirmar">Confirmar</button>
      <button class="editar">Editar</button>
      <button class="cancelar">Cancelar</button>
    </td>
  </tr>
  <tr>
    <td>Rafael Souza</td>
    <td>4</td>
    <td>19:45</td>
    <td>Confirmada</td>
    <td>18</td>
    <td class="acoes">
      <button class="concluida">Concluir</button>
      <button class="editar">Editar</button>
      <button class="cancelar">Cancelar</button>
    </td>
  </tr>
  <tr>
    <td>Isabela Fonseca</td>
    <td>2</td>
    <td>20:50</td>
    <td>Aguardando</td>
    <td>19</td>
    <td class="acoes">
      <button class="confirmar">Confirmar</button>
      <button class="editar">Editar</button>
      <button class="cancelar">Cancelar</button>
    </td>
  </tr>
  <tr>
    <td>Thiago Carvalho</td>
    <td>5</td>
    <td>21:05</td>
    <td>Confirmada</td>
    <td>20</td>
    <td class="acoes">
      <button class="concluida">Concluir</button>
      <button class="editar">Editar</button>
      <button class="cancelar">Cancelar</button>
    </td>
  </tr>
  <tr>
    <td>Carla Albuquerque</td>
    <td>3</td>
    <td>18:35</td>
    <td>Aguardando</td>
    <td>21</td>
    <td class="acoes">
      <button class="confirmar">Confirmar</button>
      <button class="editar">Editar</button>
      <button class="cancelar">Cancelar</button>
    </td>
  </tr>
  <tr>
    <td>Eduardo Lima</td>
    <td>4</td>
    <td>19:20</td>
    <td>Confirmada</td>
    <td>

  </table>
</body>
</html>
